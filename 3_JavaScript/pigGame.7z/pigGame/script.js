// GLOBAL VARIABLES

const winningScore = 100;
let playerOneScore = 0; // player one total score
let playerTwoScore = 0; // player two total score
let roundScore = 0; // round score

let activePlayer = 0; // 0 is playerOne, 1 is playerTwo
